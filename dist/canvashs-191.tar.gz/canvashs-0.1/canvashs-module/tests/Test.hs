{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
-- Look at other working tests for the exact structure ;-)