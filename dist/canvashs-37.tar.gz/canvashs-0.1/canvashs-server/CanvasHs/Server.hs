-- |The server module.
module CanvasHs.Server() where
